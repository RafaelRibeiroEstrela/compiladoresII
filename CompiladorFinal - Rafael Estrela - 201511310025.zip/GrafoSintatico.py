
from PIL import Image

def grafoSintatico():
    
    image = Image.open('GrafoSintatico.png')
    image.show()
    
    
    '''
    #Estrutura do grafo sintatico
    
    grafo = {

    '<programa>': ['program' , 'ident' , '<corpo>', '.'],
    '<corpo>': ['<dc>', 'begin', '<comandos>', 'end'],
    '<dc>': ['<dc_v>', '<mais_dc>', '|', '<dc_p>', '<mais_dc>', '|', 'λ'],
    '<mais_dc>': [';', '<dc>', '|', 'λ'],
    '<dc_v>': ['var', '<variaveis>', ':', '<tipo_var>'],
    '<tipo_var>': ['real', '|', 'integer'],
    '<variaveis>': ['ident', '<mais_var>'],
    '<mais_var>': [',', '<variaveis>', '|', 'λ'],
    '<dc_p>': ['procedure', 'ident', '<parametros>', '<corpo_p>'],
    '<parametros>': ['(', '<lista_par>', ')', '|', 'λ'],
    '<lista_par>': ['<variaveis>', ':', '<tipo_var>', '<mais_par>'],
    '<mais_par>': [';', '<lista_par>', '|', 'λ'],
    '<corpo_p>': ['<dc_loc>', 'begin', '<comandos>', 'end'],
    '<dc_loc>': ['<dc_v>', '<mais_dcloc>', '|', 'λ'],
    '<mais_dcloc>': [';', '<dc_loc>', '|', 'λ'],
    '<lista_arg>': ['(', '<argumentos>', ')', '|', 'λ'],
    '<argumentos>': ['ident', '<mais_ident>'],
    '<mais_ident>': [';', '<argumentos>', '|', 'λ'],
    '<pfalsa>': ['else', '<comandos>', '|', 'λ'],
    '<comandos>': ['<comando>', '<mais_comandos>'],
    '<mais_comandos>': [';', '<comandos>', '|', 'λ'],
    '<comando>': ['read', '(', '<variaveis>', ')',  '|', 
                    'write', '(', '<variaveis>', ')', '|', 
                    'while', '<condicao>', 'do', '<comandos>', '$', '|',
                    'if', '<condicao>', 'then', '<comandos>', '<pfalsa>', '$', '|',
                    'ident', '<restoIdent>'],
    '<restoIdent>': [':=', '<expressao>', '|', '<lista_arg>'],
    '<condicao>': ['<expressao>', '<relacao>', '<expressao>'],
    '<relacao>': ['=', '|', '<>', '|', '>=', '|', '<=', '|', '>', '|', '<'],
    '<expressao>': ['<termo>', '<outros_termos>'],
    '<op_un>': ['+', '|', '-', '|', 'λ'],
    '<outros_termos>': ['<op_ad>', '<termo>', '<outros_termos>', '|', 'λ'],
    '<op_ad>': ['+', '|', '-'],
    '<termo>': ['<op_un>', '<fator>', '<mais_fatores>'],
    '<mais_fatores>': ['<op_mul>', '<fator>', '<mais_fatores>', '|', 'λ'],
    '<op_mul>': ['*', '|', '/'],
    '<fator>': ['ident', '|', 'numero_int', '|', 'numero_real', '|', '(', '<expressao>', ')']
    }

    keys = list(grafo)

    cont = 0

    print ("GRAFO SINTATICO")

    for i in keys:

        print (i, ':')

        for j in range(len(grafo[i])):

            if (grafo[i][j] == '|'):
                cont = 1
                continue

            if (j == 0 or cont == 1):
                print ('-> ', end = '')

            if (j == len(grafo[i]) - 1 or grafo[i][j+1] == '|'):
                print (grafo[i][j])

            else:
                print (grafo[i][j], '-> ', end = '')

            cont = 0

        print ('\n')
    
    '''

